'use client'

import { useState, useEffect } from 'react'
import { motion, AnimatePresence } from 'framer-motion'
import { Github, Linkedin, Mail, MapPin, Phone, Briefcase, GraduationCap, Award, User, ChevronRight, ChevronLeft } from 'lucide-react'

export default function Portfolio() {
  const [activeSkill, setActiveSkill] = useState(0)

  const personalInfo = {
    name: "Viswath Ravinoothala",
    title: "Aspiring Computer Science Professional",
    location: "Visakhapatnam, Andhra Pradesh 531019",
    phone: "+91 9948181520",
    email: "viswathravinoothala@gmail.com",
    linkedin: "https://www.linkedin.com/in/viswathravinoothala",
    github: "https://github.com/viswathravinoothala"
  }

  const skills = [
    { name: "Python", level: 80 },
    { name: "SQL", level: 75 },
    { name: "Power-BI", level: 70 },
    { name: "Problem Solving", level: 85 },
    { name: "Fast Learner", level: 90 },
    { name: "Project Management", level: 75 }
  ]

  const experience = [
    {
      title: "Internship Student",
      company: "Datapro",
      location: "Visakhapatnam, India",
      duration: "04/2023 - 04/2023",
      responsibilities: [
        "Debugged existing codebase and identified solutions for improvement.",
        "Performed system analysis to identify areas for improvement in performance and scalability.",
        "Optimized application performance by reducing response times and memory usage.",
        "Performed customer-focused design analysis resulting in implementation of user-driven changes."
      ]
    }
  ]

  const education = [
    {
      degree: "Bachelor of Science in Computer Science",
      institution: "DADI VEERUNAIDU DEGREE COLLEGE",
      location: "Anakapalli, Andhra Pradesh, India",
      year: "10/2023"
    },
    {
      degree: "Intermediate (MPC)",
      institution: "NARAYA JUNIOR COLLEGE",
      location: "Anakapalli, Andhra Pradesh, India",
      year: "05/2020"
    },
    {
      degree: "SSC",
      institution: "NARAYANA HIGH SCHOOL",
      location: "Anakapalli, Andhra Pradesh, India",
      year: "05/2018"
    }
  ]

  const certifications = [
    "AWS (Amazon Web Service) Cloud Foundations",
    "Employability Skill Development"
  ]

  const accomplishments = [
    "Rewarded by silver medal NSO organisation in 2018"
  ]

  useEffect(() => {
    const interval = setInterval(() => {
      setActiveSkill((prev) => (prev + 1) % skills.length)
    }, 3000)
    return () => clearInterval(interval)
  }, [])

  return (
    <div className="min-h-screen bg-gradient-to-br from-gray-900 to-gray-800 text-white p-8">
      <header className="max-w-4xl mx-auto text-center mb-16">
        <h1 className="text-5xl font-bold mb-4">{personalInfo.name}</h1>
        <p className="text-xl text-gray-400 mb-8">{personalInfo.title}</p>
        <div className="flex justify-center space-x-4">
          <a href={`mailto:${personalInfo.email}`} className="hover:text-blue-400 transition-colors">
            <Mail className="w-6 h-6" />
          </a>
          <a href={personalInfo.linkedin} target="_blank" rel="noopener noreferrer" className="hover:text-blue-400 transition-colors">
            <Linkedin className="w-6 h-6" />
          </a>
          <a href={personalInfo.github} target="_blank" rel="noopener noreferrer" className="hover:text-blue-400 transition-colors">
            <Github className="w-6 h-6" />
          </a>
        </div>
      </header>

      <main className="max-w-4xl mx-auto">
        <section className="mb-16">
          <h2 className="text-3xl font-semibold mb-8">Skills Showcase</h2>
          <div className="relative h-40 bg-gray-700 rounded-lg overflow-hidden">
            <AnimatePresence>
              <motion.div
                key={activeSkill}
                initial={{ x: 300, opacity: 0 }}
                animate={{ x: 0, opacity: 1 }}
                exit={{ x: -300, opacity: 0 }}
                transition={{ duration: 0.5 }}
                className="absolute inset-0 flex items-center justify-center"
              >
                <div className="text-center">
                  <h3 className="text-2xl font-semibold mb-2">{skills[activeSkill].name}</h3>
                  <div className="w-64 bg-gray-600 rounded-full h-4">
                    <div
                      className="bg-blue-500 h-4 rounded-full"
                      style={{ width: `${skills[activeSkill].level}%` }}
                    ></div>
                  </div>
                </div>
              </motion.div>
            </AnimatePresence>
            <button
              onClick={() => setActiveSkill((prev) => (prev - 1 + skills.length) % skills.length)}
              className="absolute left-2 top-1/2 transform -translate-y-1/2 bg-gray-800 rounded-full p-2"
            >
              <ChevronLeft className="w-6 h-6" />
            </button>
            <button
              onClick={() => setActiveSkill((prev) => (prev + 1) % skills.length)}
              className="absolute right-2 top-1/2 transform -translate-y-1/2 bg-gray-800 rounded-full p-2"
            >
              <ChevronRight className="w-6 h-6" />
            </button>
          </div>
        </section>

        <section className="mb-16">
          <h2 className="text-3xl font-semibold mb-8">Experience & Education</h2>
          <div className="space-y-8">
            {[...experience, ...education].map((item, index) => (
              <div key={index} className="relative pl-8 pb-8 border-l-2 border-gray-700">
                <div className="absolute left-0 top-0 w-4 h-4 bg-blue-500 rounded-full -translate-x-1/2"></div>
                <h3 className="text-xl font-semibold mb-2">{item.title || item.degree}</h3>
                <p className="text-gray-400 mb-2">{item.company || item.institution}</p>
                <p className="text-gray-400 mb-2">{item.location}</p>
                <p className="text-gray-400 mb-4">{item.duration || item.year}</p>
                {item.responsibilities && (
                  <ul className="list-disc list-inside text-gray-300">
                    {item.responsibilities.map((resp, idx) => (
                      <li key={idx}>{resp}</li>
                    ))}
                  </ul>
                )}
              </div>
            ))}
          </div>
        </section>

        <section className="mb-16">
          <h2 className="text-3xl font-semibold mb-8">Certifications & Accomplishments</h2>
          <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
            <div>
              <h3 className="text-2xl font-semibold mb-4">Certifications</h3>
              <ul className="list-disc list-inside text-gray-300">
                {certifications.map((cert, index) => (
                  <li key={index}>{cert}</li>
                ))}
              </ul>
            </div>
            <div>
              <h3 className="text-2xl font-semibold mb-4">Accomplishments</h3>
              <ul className="list-disc list-inside text-gray-300">
                {accomplishments.map((accomp, index) => (
                  <li key={index}>{accomp}</li>
                ))}
              </ul>
            </div>
          </div>
        </section>
      </main>

      <footer className="max-w-4xl mx-auto text-center text-gray-400">
        <p>&copy; 2023 {personalInfo.name}. All rights reserved.</p>
      </footer>
    </div>
  )
}